#!/usr/bin/env bash

echo "Run simple python HTTP server"

# read first argument
# echo "$1"

port_number="${1:-9000}"  ## set port, default 9000
echo "Port number: $port_number"

python3 -m http.server $port_number

echo "Server is running"

